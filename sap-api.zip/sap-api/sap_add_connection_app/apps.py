from django.apps import AppConfig


class SapAddConnectionAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sap_add_connection_app'
