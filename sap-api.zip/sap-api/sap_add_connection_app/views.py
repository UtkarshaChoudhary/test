from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from pyrfc import Connection, ABAPApplicationError, ABAPRuntimeError, LogonError, CommunicationError
from .models import SAP_Token
from rest_framework.parsers import JSONParser
import base64
from django.shortcuts import render


## API for testing Django is running or not.
## url- http://127.0.0.1:8000/
class Welcome(APIView):
    def get(self,request,format=None):
        try:
            return Response({"message":"Welcome to SAP Automation ","statusCode":"200","responseType":"Success"}, status=status.HTTP_200_OK)    
        except Exception as e:
            return Response({"message": f"Error due to:{str(e)}", "statusCode": "400"}, status=status.HTTP_400_BAD_REQUEST)   

## START SAP Add Connection 
## URL- http://127.0.0.1:8000/SAP_Connection
class SAPConnectionList(APIView):
    ## Post  request for SAP add connection 
    def post(self, request, format=None):
        try:
            data=JSONParser().parse(request)
            print(data)
            connName = data['connName']
            user = data['user']
            passwd = data['passwd']
            ashost = data['ashost']
            sysnr = data['sysnr']
            client = data['client']

            ## password decrypt here (a to b )
            passwd = base64.b64decode(passwd).decode('utf-8')
           
            conn = Connection(user=user, passwd=passwd, ashost=ashost, sysnr=sysnr,client=client)
            # print("conn",conn)
            if conn:
                    ## check the status of conn object
                    # print(conn.alive)
                    
                    conn.close()
                    
                    return Response({"message":"Connection Added Successfully ","statusCode":"200","responseType":"Success"}, status=status.HTTP_200_OK)    
                                            
            else:
                    return Response({"message":"Invalid data","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except CommunicationError:
            return Response({"message":"You Could not Connect to Server.","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except LogonError:
            return Response({"message":"You Could not add connection. Wrong credentials?","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except (ABAPApplicationError, ABAPRuntimeError):
            return Response({"message":"An ABAP error occurred.","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"message": f"Error due to:{str(e)}", "statusCode": "400"}, status=status.HTTP_400_BAD_REQUEST)

## END SAP Add Connection