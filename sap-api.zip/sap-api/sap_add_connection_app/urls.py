from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from sap_add_connection_app.views import SAPConnectionList,Welcome#, Websocket
from . import views
urlpatterns = [
	## SAP Add Connection -  http://127.0.0.1:8000/SAP_Connection
   	path('SAP_Connection', SAPConnectionList.as_view()),

	## Django test Url for Django is running or not- GET method -  http://127.0.0.1:8000/
	path('',Welcome.as_view()),
]
urlpatterns = format_suffix_patterns(urlpatterns)