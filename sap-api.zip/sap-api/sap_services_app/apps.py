from django.apps import AppConfig


class SapServicesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sap_services_app'
