from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from sap_services_app.views import SAPLockServiceList,SAPUnLockServiceList,SAPResetPasswordServiceList,SAPChangePasswordServiceList
urlpatterns = [
	## SAP User Lock Service URL- http://127.0.0.1:8000/services/userLock
   	path('userLock', SAPLockServiceList.as_view()),

	## SAP User Unlock service URL- http://127.0.0.1:8000/services/userUnLock
	path('userUnLock', SAPUnLockServiceList.as_view()), 

	## SAP user ResetPassword service URL - http://127.0.0.1:8000/services/resetPassword
	path('resetPassword', SAPResetPasswordServiceList.as_view()), 

	## SAP user ChangePassword service URL - http://127.0.0.1:8000/services/changePassword
	path('changePassword', SAPChangePasswordServiceList.as_view()), 
]
urlpatterns = format_suffix_patterns(urlpatterns)