from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.parsers import JSONParser
from pyrfc import Connection, ABAPApplicationError, ABAPRuntimeError, LogonError, CommunicationError
import base64

## START SAP USER LOCK Service  
## URL- http://127.0.0.1:8000/services/userLock
class SAPLockServiceList(APIView):
    ## call every time pyrfc class and get conn object 
    def sapConn(self,ASHOST,CLIENT,SYSNR,USER,PASSWD):  
        conn = Connection(ashost=ASHOST, sysnr=SYSNR, client=CLIENT, user=USER, passwd=PASSWD)
        return conn     

    ## Import parameters pass to SAP Table
    def qry(self,conn,function_module,USER_ID):    
        userId=[{"USER_ID": USER_ID}]   
        # print("user id=",userId)    
        tables= conn.call(function_module,USER=userId)
        print("tables=",tables)
        return tables

    ## SAP service - user Lock
    ## POST request for userLock //http://localhost:8000/services/userLock
    def post(self, request, format=None):
        try:
            data = JSONParser().parse(request)
            print(data)
            userId= data['userId'].upper()
            connName= data['connName']

            ## data needed for dynamically calling pyrfc
            ashost = data['ashost']
            client = data['client']
            sysnr = data['sysnr']
            user = data['user']
            passwd = data['passwd']
            
            # ## password decrypt here
            passwd = base64.b64decode(passwd).decode('utf-8')
            
            conn = self.sapConn(ashost,client,sysnr,user,passwd) 

            # # SAP TMS Query for USER_LOCK
            function_module = "ZRFC_USER_LOCK"
         
            results = self.qry(conn,function_module,userId)
            # print("results=",results)
            ## here only send message to FE
            output=results['OUTPUT'][0]
            message=output["MESSAGE"]
            
            if results['STATUS']=='S':
                if output["TYPE"]=='S':
                    conn.close()
                    return Response({"message":message,"statusCode":"200","responseType":"Success"}, status=status.HTTP_200_OK)
                elif output["TYPE"]=='E':
                    conn.close()
                    return Response({"message":message,"statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
            elif results['STATUS']=='E':
                conn.close()
                return Response({"message":message,"statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
            
        except CommunicationError:
            return Response({"message":"You Could not Connect to Server.","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except LogonError:
            return Response({"message":"User is Locked! Contact to administrator","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except (ABAPApplicationError, ABAPRuntimeError) as e:
            return Response({"message":"An error occurred.","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"message": f"Error due to:{str(e)}", "statusCode": "400"}, status=status.HTTP_400_BAD_REQUEST)
## END SAP USER LOCK for perticular user


## START SAP UNLOCK service
## URL- http://127.0.0.1:8000/services/userUnLock
class SAPUnLockServiceList(SAPLockServiceList,APIView):
    ## POST request for userUnLock //http://localhost:8000/services/userUnLock
    def post(self, request, format=None):
        try:
            data = JSONParser().parse(request)
            print(data)
            userId= data['userId'].upper()
            connName= data['connName']

            ## data needed for dynamically calling pyrfc
            ashost = data['ashost']
            client = data['client']
            sysnr = data['sysnr']
            user = data['user']
            passwd = data['passwd']
            
            # ## password decrypt here
            passwd = base64.b64decode(passwd).decode('utf-8')
            
            conn = self.sapConn(ashost,client,sysnr,user,passwd) 

            # # SAP Query for USER UNLOCK
            function_module = "ZRFC_USER_UNLOCK"

            results = SAPLockServiceList.qry(self,conn,function_module,userId)
            # print("results=",results)
            ## here only send message to FE
            
            output=results['OUTPUT'][0]
            message=output["MESSAGE"]
            
            if results['STATUS']=='S':
                if output["TYPE"]=='S':
                    conn.close()
                    return Response({"message":message,"statusCode":"200","responseType":"Success"}, status=status.HTTP_200_OK)
                elif output["TYPE"]=='E':
                    conn.close()
                    return Response({"message":message,"statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
            elif results['STATUS']=='E':
                conn.close()
                return Response({"message":message,"statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
            
        except CommunicationError:
            return Response({"message":"You Could not Connect to Server.","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except LogonError:
            return Response({"message":"User is Locked! Contact to administrator","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except (ABAPApplicationError, ABAPRuntimeError) as e:
            print("error=",e)
            return Response({"message":"An error occurred.","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"message": f"Error due to:{str(e)}", "statusCode": "400"}, status=status.HTTP_400_BAD_REQUEST)
## END SAP USER UNLOCK for perticular user


## START SAP Reset Password service
#please change url -comment for rajani
## URL- http://127.0.0.1:8000/services/changePassword
class SAPResetPasswordServiceList(SAPLockServiceList,APIView):
    ## Import parameters pass to SAP Table
    def qry(self,conn,function_module,user_id,event,newPasswd):    
            user_pwd_change=[{"USER": user_id,"PASSWORD":newPasswd}]   
            # print("user id=",userId)    
            tables=conn.call(function_module,USER=user_pwd_change,EVENT=event)

            print("tables=",tables)
            return tables

    ## POST request for Reset password 
    def post(self, request, format=None):
        try:
            data = JSONParser().parse(request)
            print(data)
            userId= data['userId'].upper()
            connName= data['connName']
            newPasswd= data['newPasswd']
            confirmPasswd= data['confirmPasswd']

            ## data needed for dynamically calling pyrfc
            ashost = data['ashost']
            client = data['client']
            sysnr = data['sysnr']
            user = data['user']
            passwd = data['passwd']
        
            ## user newpassword decrypt here
            newPasswd = base64.b64decode(newPasswd).decode('utf-8')
            ## sap connection password decrypt here
            passwd = base64.b64decode(passwd).decode('utf-8')
            
            ## SAP connection before performing any action in SAP 
            conn = SAPLockServiceList.sapConn(self,ashost,client,sysnr,user,passwd)             

            # # SAP Query for Reset Password
            function_module = "ZRFC_USER_PWD_CHANGE"
            event = "EVENT_PWD_RESET"
            ## call ZRFC here
            results = self.qry(conn,function_module,userId,event,newPasswd)
            # print("results=",results)
            ## here only send message to FE
            output=results['OUTPUT'][0]
            message=output["MESSAGE"]
            
            if results['STATUS']=='S':
                if output["TYPE"]=='S':
                    conn.close()
                    return Response({"message":message,"statusCode":"200","responseType":"Success"}, status=status.HTTP_200_OK)
                elif output["TYPE"]=='E':
                    conn.close()
                    return Response({"message":message,"statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
            elif results['STATUS']=='E':
                conn.close()
                return Response({"message":message,"statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
            
        except CommunicationError:
            return Response({"message":"You Could not Connect to Server.","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except LogonError:
            return Response({"message":"You Could not add connection. Wrong credentials?","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except (ABAPApplicationError, ABAPRuntimeError) as e:
            print("error=",e)
            return Response({"message":"An error occurred.","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"message": f"Error due to:{str(e)}", "statusCode": "400"}, status=status.HTTP_400_BAD_REQUEST)

## END SAP Reset password service


## START SAP Change Password service
## URL- http://127.0.0.1:8000/services/changePassword
class SAPChangePasswordServiceList(SAPLockServiceList,APIView):
    ## Import parameters pass to SAP Table
    def qry(self,conn,function_module,user_id,event,oldPasswd,newPasswd):    
            userPwdChange=[{"USER": user_id,"PASSWORD":oldPasswd,"NEW_PASSWORD":newPasswd}]   
            # print("user id=",userId)    
            tables=conn.call(function_module,USER=userPwdChange,EVENT=event)
            print("tables=",tables)
            return tables

    ## POST request for change password 
    def post(self, request, format=None):
        try:
            data = JSONParser().parse(request)
            print(data)
            userId= data['userId'].upper()
            connName= data['connName']
            oldPasswd= data['oldPasswd']
            newPasswd= data['newPasswd']

            ## data needed for dynamically calling pyrfc
            ashost = data['ashost']
            client = data['client']
            sysnr = data['sysnr']
            user = data['user']
            passwd = data['passwd']
        
            ## user oldpassword decrypt here
            # oldPasswd = base64.b64decode(oldPasswd).decode('utf-8')

            ## user newpassword decrypt here
            # newPasswd = base64.b64decode(newPasswd).decode('utf-8')

            ## sap connection password decrypt here
            passwd = base64.b64decode(passwd).decode('utf-8')
            
            ## SAP connection before performing any action in SAP 
            conn = SAPLockServiceList.sapConn(self,ashost,client,sysnr,user,passwd)             

            # # SAP Query for Change Password
            function_module = "ZRFC_USER_PWD_CHANGE"
            event = "EVENT_PWD_CHANGE"
            ## call ZRFC here
            results = self.qry(conn,function_module,userId,event,oldPasswd,newPasswd)
            # print("results= ",results)
            output=results['OUTPUT'][0]
            message=output["MESSAGE"]
            
            if results['STATUS']=='S':
                if output["TYPE"]=='S':
                    conn.close()
                    print("message=",message)
                    return Response({"message":message,"statusCode":"200","responseType":"Success"}, status=status.HTTP_200_OK)
                elif output["TYPE"]=='E':
                    conn.close()
                    print("message=",message)
                    return Response({"message":message,"statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
            elif results['STATUS']=='E':
                conn.close()
                return Response({"message":message,"statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
            
        except CommunicationError:
            return Response({"message":"You Could not Connect to Server.","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except LogonError:
            return Response({"message":"You Could not add connection. Wrong credentials?","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except (ABAPApplicationError, ABAPRuntimeError) as e:
            print("error=",e)
            return Response({"message":"An error occurred.","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"message": f"Error due to:{str(e)}", "statusCode": "400"}, status=status.HTTP_400_BAD_REQUEST)

## END SAP change password service