from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from TMS_app.views import SAP_TMS_ServiceList,SAPTRReleaseServiceList
urlpatterns = [
	## SAP TR List Details for perticular user. URL-http://127.0.0.1:8000/tms/tr_list
   	path('tr_list', SAP_TMS_ServiceList.as_view()),

	## SAP TR Release. URL-http://127.0.0.1:8000/tms/tr_release
	path('tr_release',SAPTRReleaseServiceList.as_view())	
]
urlpatterns = format_suffix_patterns(urlpatterns)