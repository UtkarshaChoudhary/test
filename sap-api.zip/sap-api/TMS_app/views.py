# import re
# from django.http import Http404, JsonResponse
# from datetime import datetime
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.parsers import JSONParser
from pyrfc import Connection, ABAPApplicationError, ABAPRuntimeError, LogonError, CommunicationError
import base64
## START SAP TR LIST Details for perticular user
## URL- http://127.0.0.1:8000/tms/tr_list
class SAP_TMS_ServiceList(APIView):
    ## call every time pyrfc class and get conn object 
    def sapConn(self,ASHOST,CLIENT,SYSNR,USER,PASSWD):  
        conn = Connection(ashost=ASHOST, sysnr=SYSNR, client=CLIENT, user=USER, passwd=PASSWD)
        return conn     

    ## SAP Query- TR details
    def qry(self,conn,function_module,event,USER_ID):    
        user_id=[{"USER_ID": USER_ID}]  
        print("user id=",user_id)     
        tables = conn.call(function_module,EVENT=event,USER=user_id)
        # print("tables=",tables)
        return tables

    ## SAP service - TMS user TR List
    ## POST request for tms //http://localhost:8000/tms/tr_list
    def post(self, request, format=None):
        try:
            data = JSONParser().parse(request)
            print(data)
            userId= data['userId'].upper()
            connName= data['connName']

            ## data needed for dynamically calling pyrfc
            ashost = data['ashost']
            client = data['client']
            sysnr = data['sysnr']
            user = data['user']
            passwd = data['passwd']
            
            # ## password decrypt here
            passwd = base64.b64decode(passwd).decode('utf-8')
            
            conn = self.sapConn(ashost,client,sysnr,user,passwd) 

            # # SAP TMS Query for TR details
            function_module = "ZGET_TR_DEATILS_RFC"
            event = "EVENT_TR_DETAILS"
            results = self.qry(conn,function_module,event,userId)
            
            if results['STATUS']=='S':
                conn.close()
                return Response({"status":results['STATUS'],"output":results['OUTPUT'],"statusCode":"200","responseType":"Success"}, status=status.HTTP_200_OK)
            elif results['STATUS']=='E':
                conn.close()
                return Response({"status":results['STATUS'],"output":results['OUTPUT'],"statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)

        except CommunicationError:
            return Response({"message":"You Could not Connect to Server.","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except LogonError:
            return Response({"message":"User is Locked! Contact to administrator","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except (ABAPApplicationError, ABAPRuntimeError):
            return Response({"message":"An error occurred.","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"message": f"Error due to:{str(e)}", "statusCode": "400"}, status=status.HTTP_400_BAD_REQUEST)
## END SAP TR LIST Details for perticular user

## START SAP service - TMS TR Release
## URL - http://127.0.0.1:8000/tms/tr_release
class SAPTRReleaseServiceList(SAP_TMS_ServiceList,APIView):
    ## SAP TR Release Import parameters pass to SAP Z-RFC
    def qry(self,conn,function_module,event,tr_list): 
        # print("tr details=",tr_list)
        tr_list = [{"TRKORR":x} for x in tr_list]    
        # print("TR_request",tr_list)  
        tables = conn.call(function_module,EVENT=event,TR_LIST=tr_list)
       
        # print("tables=",tables)
        return tables
        
    ## POST request for tms tr movement //http://10.0.0.38:8000/tms/tr_release
    def post(self, request, format=None):
        try:
            data = JSONParser().parse(request)
            print(data)
            tr_list = data['tr_list']
            # print("tr_list",tr_list)
            connName = data['connName']
            ## data needed for dynamically calling pyrfc
            ashost = data['ashost']
            client = data['client']
            sysnr = data['sysnr']
            user = data['user']
            passwd = data['passwd']
            
            ## password decrypt here
            passwd = base64.b64decode(passwd).decode('utf-8')          
            
            conn = SAP_TMS_ServiceList.sapConn(self,ashost,client,sysnr,user,passwd) 
            # print("conn=",conn)
            ## query SAP
            function_module = "ZGET_TR_DEATILS_RFC"
            event ="EVENT_TR_RELEASE"
            results=self.qry(conn,function_module,event,tr_list)
            # print("results",results)
            if results['STATUS']=='S':
                conn.close()
                return Response({"status":results['STATUS'],"output":results['OUTPUT'],"statusCode":"200","responseType":"Success",},status=status.HTTP_200_OK)
            elif results['STATUS']=='E':
                conn.close()
                return Response({"status":results['STATUS'],"output":results['OUTPUT'],"statusCode":"400","responseType":"Failure",},status=status.HTTP_400_BAD_REQUEST)

        except CommunicationError:
            return Response({"message":"You Could not Connect to Server.","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except LogonError:
            return Response({"message":"User is Locked! Contact to administrator","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except (ABAPApplicationError, ABAPRuntimeError) as e:
            print("error= ",e)
            return Response({"message":"An error occurred.","statusCode":"400","responseType":"Failure"}, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            return Response({"message": f"Error due to:{str(e)}", "statusCode": "400"}, status=status.HTTP_400_BAD_REQUEST)

## END SAP service - TMS TR Release